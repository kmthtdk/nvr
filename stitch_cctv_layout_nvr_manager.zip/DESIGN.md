---
name: Obsidian Sentinel
colors:
  surface: '#0f1418'
  surface-dim: '#0f1418'
  surface-bright: '#343a3e'
  surface-container-lowest: '#0a0f12'
  surface-container-low: '#171c20'
  surface-container: '#1b2024'
  surface-container-high: '#252b2e'
  surface-container-highest: '#303539'
  on-surface: '#dee3e8'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dee3e8'
  inverse-on-surface: '#2c3135'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#bcc7de'
  on-secondary: '#263143'
  secondary-container: '#3e495d'
  on-secondary-container: '#aeb9d0'
  tertiary: '#c5cce6'
  on-tertiary: '#283044'
  tertiary-container: '#a9b1ca'
  on-tertiary-container: '#3c4459'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#0f1418'
  on-background: '#dee3e8'
  surface-variant: '#303539'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  metadata-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  grid-gutter: 2px
  panel-gap: 12px
  container-padding: 16px
  compact-padding: 8px
---

## Brand & Style
This design system is engineered for high-stakes surveillance and data-dense environments. The brand personality is vigilant, technical, and unobtrusive, ensuring that the interface never competes with the critical video feeds it manages.

The aesthetic follows a **Minimalist-Industrial** hybrid. It utilizes a disciplined dark-mode architecture to reduce eye strain during long shifts and uses high-contrast accents to signal status changes instantly. Every UI element is stripped of decorative flourish, favoring functional precision and structural integrity. The emotional response is one of total control, reliability, and professional-grade security.

## Colors
The palette is dominated by **Deep Charcoal (#0F172A)** to create a "void" effect, allowing video content to pop forward. The primary action color is a high-visibility Sky Blue, used sparingly for active states and primary controls.

- **Backgrounds:** Tiered layers of charcoal and slate to distinguish between global navigation and workspace panels.
- **Accents:** High-saturation Green, Red, and Amber are reserved strictly for system health, motion alerts, and critical failures.
- **Borders:** Low-contrast Slate (#1E293B) provides structural definition without creating visual noise.

## Typography
Readability is the primary constraint. **Inter** provides the versatility required for complex navigation and data-heavy tables. To distinguish system metadata (timestamps, IP addresses, bitrates) from standard UI labels, **JetBrains Mono** is introduced for its technical clarity and tabular figures.

- **Hierarchy:** Use `label-caps` for section headers in sidebars and `metadata-mono` for all camera-specific data overlays.
- **Scaling:** On mobile devices, `display-lg` should scale down to 24px to preserve screen real estate for video feeds.

## Layout & Spacing
The layout follows a **Fixed-Panel** model. The central workspace is a fluid video grid that maximizes every pixel, using ultra-thin 2px gutters to separate camera feeds. 

- **Desktop:** A three-pane layout featuring a collapsible "Camera Tree" (Left), the "Video Grid" (Center), and the "Event/PTZ Panel" (Right).
- **Breakpoints:** Mobile transitions to a single-column view where the video feed is pinned to the top, and the timeline/controls scroll vertically below.
- **Rhythm:** Use an 8px base grid for component internal spacing, but a 4px grid for dense metadata panels.

## Elevation & Depth
In this dark-themed system, depth is achieved through **Tonal Layering** rather than traditional shadows. 

- **Level 0 (Base):** #0F172A - The main application backdrop.
- **Level 1 (Panels):** #1E293B - Sidebar containers and bottom timeline bars.
- **Level 2 (Overlays):** #334155 - Context menus and tooltips.
- **Outlines:** Instead of shadows, use 1px solid borders in #334155 to define active panel focus. 
- **Video Feeds:** Feeds should appear recessed (inner stroke) when inactive and glowing (primary color outer stroke) when selected.

## Shapes
The shape language is **Soft-Industrial**. We avoid perfectly sharp corners to prevent the UI from feeling aggressive, but keep radii tight (4px) to maintain a professional, high-density appearance.

- **Buttons/Inputs:** 4px radius.
- **Video Containers:** 2px radius (near-sharp) to maximize pixel alignment of the video stream.
- **Badges/Chips:** 2px radius or sharp for a "tag" aesthetic.

## Components
Consistent styling across technical components ensures rapid operation during emergencies.

- **Video Grid:** Containers must support overlay labels (top-left) and status icons (top-right: recording, motion, audio) using a semi-transparent black scrim for legibility.
- **Timeline Slider:** A horizontal scroller with a dark grey background. Playback markers use the primary color, while motion events are highlighted in Amber.
- **Camera Tree:** Use chevron-driven nesting. Active cameras are highlighted with a subtle left-border accent in the primary color.
- **PTZ Controllers:** A minimalist 8-way directional pad with an inner "Home" button. Use high-contrast icons without text labels.
- **Status Badges:** Compact, rectangular tags. "LIVE" uses a pulsing Red dot; "ONLINE" uses a solid Green dot.
- **Input Fields:** Inset appearance with a 1px border. Focus state must use a 1px primary color border and no outer glow.